/* * * * * * * * * * * * * *
*           MAIN           *
* * * * * * * * * * * * * */

// init global variables & switches
let myMapVis,
    vaccine;

let selectedTimeRange = [];
let selectedState = '';
let selectedCategory = 'absCases';
let selectedDate = "";


// load data using promises
let promises = [

    // d3.json("https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json"),  // not projected -> you need to do it
    d3.json("https://cdn.jsdelivr.net/npm/us-atlas@3/states-albers-10m.json"), // already projected -> you can just scale it to ft your browser window
    d3.csv("data/covid_data.csv"),
    d3.csv("data/census_usa.csv"),
    d3.csv("data/dailyCases2.csv"),
    d3.csv("data/sewage_concentration.csv"),
    d3.csv("data/vaccine_mandate_dailycases.csv"),
    d3.csv("data/dailyCases2edited.csv"),
    d3.json("data/cb_2014_us_county_5m.json")
];

Promise.all(promises)
    .then(function (data) {
        initMainPage(data)
    })
    .catch(function (err) {
        console.log(err)
    });

// initMainPage
function initMainPage(dataArray) {


    var cummVacc = 0;
    let parseDate = d3.timeParse("%m/%d/%Y");
    dataArray[5].forEach(entry=>
    {

        entry.Date = parseDate(entry.Date);
        entry["New Cases"] =+ entry["New Cases"];
        entry["Daily Test"] =+ entry["Daily Test"];
        entry["Total Doses"] =+ entry["Total Doses"];
        entry["Dose 1"] =+ entry["Dose 1"];
        //entry["Total Doses"] = +entry["Total Doses"]
        entry["cummulativeVaccine"] = cummVacc + entry["Dose 1"];
        cummVacc = entry["cummulativeVaccine"];
    })

    dataArray[6].forEach(entry=>
    {
        entry.Date = parseDate(entry.Date);
        entry["NewCases"] =+ entry["NewCases"];

    });



    // log data
    console.log('check out the data', dataArray);

    // TODO - init map
    myMapVis = new MapVis('mapDiv', dataArray[1], dataArray[2], dataArray[0]);


    // init brush
    daily_cases_timeline = new BrushVis('brushDiv', dataArray[3]);


    daily_cases_tests = new CasesTest('testingAndCases', dataArray[5]);

    vaccine = new Vaccine("vaccinatedPopulation", dataArray[5]);

    county = new CountyVis("mandateMap", dataArray[7], dataArray[5] );

    combinet = new CombineTimelines("new-demo-id");


}
