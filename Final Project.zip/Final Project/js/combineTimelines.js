/* * * * * * * * * * * * * *
*      class BarVis        *
* * * * * * * * * * * * * */


class CombineTimelines {

    constructor(parentElement){

        this.parentElement = parentElement;

        this.initVis()
    }

    initVis(){
        let vis = this;

        vis.margin = {top: 20, right: 60, bottom: 20, left: 40};


        vis.width = document.getElementById(vis.parentElement).getBoundingClientRect().width - vis.margin.left - vis.margin.right;
        vis.height = document.getElementById(vis.parentElement).getBoundingClientRect().height - vis.margin.top - vis.margin.bottom;

        // init drawing area
        vis.svg = d3.select("#" + vis.parentElement).append("svg")
            .attr("width", vis.width + vis.margin.left + vis.margin.right)
            .attr("height", vis.height + vis.margin.top + vis.margin.bottom)
            .append('g')
            .attr('transform', `translate (${vis.margin.left}, ${vis.margin.top})`);




        milestones('#' + vis.parentElement)
            .mapping({
                'category':"category",
                'entries': "entries",
                'timestamp': 'year',
                'text': 'title'
            })
            .parseTime('%Y')
            .aggregateBy('year')
            .orientation("horizontal")
            .optimize(true)
            .render([
                {"category" : "CORONA",
                 "entries" : [
                     {
                         "year": 1920,
                         "title" : "Earliest reports from an acute respiratory infection of domesticated chickens in North America"
                     },
                     {
                         "year": 1931,
                         "title" : "First detailed reports about respiratory infection checkens in North Dakota emerges"
                     },
                     {
                         "year": 1933,
                         "title" : "Virus is isolated by Leland David and Carl Alfred Brandly"
                     },
                     {
                         "year": 1937,
                         "title" : "Virus is cultivated for the first time"
                     },
                     {
                         "year": 1940,
                         "title" : "Two more animal coronaviruses, JHM that causes brain disease (murine encephalitis) and mouse hepatitis virus (MHV) that causes hepatitis in mice were discovered"
                     },
                     {
                         "year": 1960,
                         "title" : "Human coronaviruses, discovered"
                     },
                     {
                         "year": 1965,
                         "title" : "New novel coronovirus is cultivated using the serially passing technique in the lab"
                     },
                     {
                         "year": 1967,
                         "title" : "The structures of IBV, B814 and 229E are all found to be related by using an electron microsocope"
                     },
                     {
                         "year": 2003,
                         "title" : "SARS outbreak"
                     },
                     {
                         "year": 2012,
                         "title" : "MERS outbreak"
                     },
                     {
                         "year": 2020,
                         "title" : "SARS COV-2 outbreak discovered in Wuhan, China\n"
                     },

                 ]
                },

                {"category" : "mRNA Technology",
                    "entries" : [
                        {
                            "year": 1961,
                            "title" : "mRNA Technology was discovered"
                        },
                        {
                            "year": 1969,
                            "title" : "First proteins from isolated mRNA in lab"
                        },
                        {
                            "year": 1984,
                            "title" : "mRNA synthesized in lab"
                        },
                        {
                            "year": 1992,
                            "title" : "mRNA tested as a treatment (in rats)"
                        },
                        {
                            "year": 1995,
                            "title" : "mRNA tested as a cancer vaccine (in mice)"
                        },
                        {
                            "year": 2005,
                            "title" : "Discovery that modified RNA evades immune detection"
                        },
                        {
                            "year": 2013,
                            "title" : "First clinical trial of mRNA vaccine for infectious disease (rabies)"
                        },
                        {
                            "year": 2020,
                            "title" : "mRNA based COVID-19 vaccines win emergency authorization"
                        },

                    ]
                }
            ]);
    }

    newUpdateVis()
    {
        let vis = this;

        if (selectedDate == "")
        {
            selectedDate = vis.data[0].Date;
        }

        vis.data.forEach(entry=>

            {
                if(entry.Date == selectedDate)
                {
                    vis.vaccine_number = entry["cummulativeVaccine"];

                    return;
                }
            }
        )


        vis.rect1.attr("width", vis.x(vis.vaccine_number));
        vis.rect2.attr("x", vis.x(vis.vaccine_number))
        vis.rect2.attr("width", vis.width - vis.x(vis.vaccine_number));

    }
}