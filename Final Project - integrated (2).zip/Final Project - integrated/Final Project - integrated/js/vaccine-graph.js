class GraphVis{
    constructor(parentElement, timelineData){
        this.parentElement = parentElement;
        this.vaccineData = timelineData;

        //for legend
        this.appendix = [{key: "Others", value: "Red"}, {key: "Covid", value: "green"}];

        this.initGraph()
    }

    initGraph(){
        let vis = this;

        vis.margin = {top: 10, right: 30, bottom: 30, left: 50};
        vis.width = document.getElementById(vis.parentElement).getBoundingClientRect().width - vis.margin.left - vis.margin.right;
        vis.height = document.getElementById(vis.parentElement).getBoundingClientRect().height - vis.margin.top - vis.margin.bottom-100;

        vis.svg = d3.select("#" + vis.parentElement).append("svg")
            .attr("width", vis.width + vis.margin.left + vis.margin.right)
            .attr("height", vis.height + vis.margin.top + vis.margin.bottom+100)
            .append("g")
            .attr("transform", "translate(" + vis.margin.left + "," + (vis.margin.top +100 )+ ")");

        //create axis
        console.log(vis.vaccineData);
        vis.minDate = d3.min(vis.vaccineData, function(d) { return d.StartDate; });
        vis.maxDate = d3.max(vis.vaccineData, function(d) { return d.EndDate; });

        vis.phasesByVaccines = d3.group(vis.vaccineData, d=>d.Phase)
        console.log("data by type of phase");
        console.log(vis.phasesByVaccines);

        vis.covidVaccineRelease = d3.min(vis.phasesByVaccines.get("Phase III"), function(d){ return d.EndDate;});
        console.log("covid release date - "+vis.covidVaccineRelease);

        vis.x = d3.scaleTime()
            .range([0,vis.width-vis.margin.left-vis.margin.right])
            .domain([vis.minDate, vis.maxDate]);

        //console.log(vis.phasesByVaccines);
        vis.phases = [];
        vis.phasesByVaccines.forEach(entry=>{
            vis.phases.push(entry[0].Phase);
        })
        console.log("phases are");
        console.log(vis.phases);

        vis.y = d3.scaleBand()
            .range([0,vis.height-vis.margin.top])
            .domain(vis.phases);

        vis.yAxis = d3.axisLeft()
            .scale(vis.y);

        vis.xAxis = d3.axisBottom()
            .scale(vis.x);

        vis.colorScheme = ["#f80f0f", "#f8840f", "#f0f80f", "#87f80f", "#f80f0f"];

        vis.colorScale = d3.scaleOrdinal()
            .domain(vis.phases)
            .range(vis.colorScheme);

        vis.yAxisGroup = vis.svg.append("g")
            .attr("class", "y-axis axis")
            .style("font-size", "0.8em")
            .attr("transform", "translate(" + (vis.margin.left-15) + ","+(-vis.margin.bottom-20)+")");

        vis.xAxisGroup = vis.svg.append("g")
            .attr("class", "x-axis axis")
            .style("font-size", "0.8em")
            .attr("transform", "translate(" + (vis.margin.left-15) + ","+(vis.height-vis.margin.bottom - vis.margin.top-20)+")");

        vis.yAxisGroup.call(vis.yAxis);

        vis.xAxisGroup.call(vis.xAxis);

        //color bands for each phase
        vis.colorBars =vis.svg.selectAll(".colorbar")
            .data(vis.phases);
        vis.colorBars.enter().append("rect")
            .attr("class","colorbar")
            .attr("x", vis.margin.left-15)
            .attr("height", (vis.height/vis.phases.length))
            .attr("y", (d)=>{console.log(d); return -20-vis.margin.bottom+vis.y(d);})
            .attr("width",vis.width-vis.margin.left-vis.margin.right)
            .attr("fill",(d)=>{console.log(vis.colorScale(d)); return vis.colorScale(d)})
            .attr("opacity","0.5");

        //vaccine bars
        vis.bar =vis.svg.selectAll(".bar")
            .data(vis.vaccineData, d=>d.Phase);
        vis.bar.enter().append("rect")
            .attr("class","bar")
            .attr("x", (d)=>{return vis.margin.left-15+vis.x(d.StartDate);})
            .attr("height", 25)
            .attr("y", (d)=>{
                if(d.Vaccine == "Covid"){
                    return vis.y(d.Phase);
                }
                else{
                    return vis.y(d.Phase)-30;
                }

            })
            .attr("width",(d)=>{return vis.x(d.EndDate)-vis.x(d.StartDate);})
            .attr("fill",(d)=>{
                if(d.Vaccine == "Covid"){
                    return "green";
                }
                else{
                    return "red";
                }
            });

        //line on vaccine releaase
        vis.svg.append("line")
            .attr("x1", vis.margin.left-15+vis.x(vis.covidVaccineRelease))  //<<== change your code here
            .attr("y1", 0)
            .attr("x2", vis.margin.left-15+vis.x(vis.covidVaccineRelease))  //<<== and here
            .attr("y2", vis.height - vis.margin.top - vis.margin.bottom - 10)
            .style("stroke-width", 2)
            .style("stroke", "black")
            .style("fill", "none");

        vis.svg.append("text")
            .attr("x", 3+vis.margin.left-15+vis.x(vis.covidVaccineRelease))
            .attr("y", vis.margin.top)
            .text(vis.covidVaccineRelease);

        vis.svg.append("text")
            .attr("x", 3+vis.margin.left-15+vis.x(vis.covidVaccineRelease))
            .attr("y",  20 + vis.margin.top)
            .text("First Covid Vaccine Released.")

        //legend
        vis.legend = vis.svg.selectAll(".legend")
            .data(vis.appendix, d=>d.key);
        vis.legend.enter().append("rect")
            .attr("x", (d,i)=>{return 500 + (90*i);})
            .attr("y", -100)
            .attr("height", 20)
            .attr("width", 20)
            .attr("fill",(d)=>{return d.value;});
        vis.legend.enter().append("text")
            .attr("x", (d,i)=>{return 522 + (90*i);})
            .attr("y", -85)
            .text((d)=>{return d.key})


        //domain band for y linear for x
        //plot
    }
}